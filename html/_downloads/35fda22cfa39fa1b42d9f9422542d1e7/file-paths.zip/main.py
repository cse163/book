def main():
    with open('bee_movie.txt') as f:
        contents = f.read()
        print(contents)


if __name__ == '__main__':
    main()
