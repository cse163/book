# Write your solution for my_set_client.py here!
