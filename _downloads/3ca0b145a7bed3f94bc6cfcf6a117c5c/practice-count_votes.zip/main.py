# Define count_votes up here!

def main():
    print(count_votes([1, 0, 1, 1, 2, 0]))


if __name__ == '__main__':
    main()
