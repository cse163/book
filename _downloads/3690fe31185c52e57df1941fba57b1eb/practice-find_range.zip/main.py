# Define find_range up here!

def main():
    print(find_range([8, 3, 5, 7, 2, 4]))


if __name__ == '__main__':
    main()
