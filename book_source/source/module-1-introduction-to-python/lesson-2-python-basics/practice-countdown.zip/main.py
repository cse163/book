# Define your countdown method up here!

def main():
    countdown(60)
    

if __name__ == '__main__':
    main()
