# Write your function here!


def main():
    print(count_words("popular_techno_song.txt"))


if __name__ == "__main__":
    main()
