import geopandas as gpd
import matplotlib.pyplot as plt

# Your code goes here!
