# Write your Point class here
