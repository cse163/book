# Define switch_pairs up here!

def main():
    print(switch_pairs("hello there"))


if __name__ == '__main__':
    main()
