# Write your function here


def main():
    print(fun_numbers(2, 16))
    print(fun_numbers(5, 5))


if __name__ == '__main__':
    main()
