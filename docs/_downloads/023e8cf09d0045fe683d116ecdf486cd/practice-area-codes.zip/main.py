# Define your function up here!

def main():
    print(area_codes([
        '123-456-7890',
        '206-123-45676',
        '123-000-0000',
        '425-999-9999'
    ]))
    

if __name__ == '__main__':
    main()
