# Write your function here!
    
    
def main():
    print(fibonacci(3))
    print(fibonacci(6))
    print(fibonacci(-2))
    

if __name__ == '__main__':
    main()
