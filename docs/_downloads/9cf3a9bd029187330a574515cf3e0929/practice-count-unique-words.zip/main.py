# Write your function here!


def main():
    print(count_unique_words("song.txt"))


if __name__ == "__main__":
    main()
