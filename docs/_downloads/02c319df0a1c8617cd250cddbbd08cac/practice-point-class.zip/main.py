# You don't need to write anything in this file!
from point import Point


def main():
    p = Point(1, 2)
    print(p.get_x())
    p.set_y(4)
    print(p.display())
    

if __name__ == '__main__':
    main()
